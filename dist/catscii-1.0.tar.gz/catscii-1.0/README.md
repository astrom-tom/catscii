# catscii

**catscii** is a very simple python module that allows one to extract in a very easy way data from ascii catalogs. 


Installation
============




How to
======

