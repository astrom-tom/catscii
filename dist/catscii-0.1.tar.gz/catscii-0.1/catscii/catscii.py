'''
This is the main file of catscii
It imports all the submodule that are used

Author: R. THOMAS
Place: ESO
Year: GPL v3.0
'''

from .open_ascii_cat import load_cat
from .extract_lines_columns import *

