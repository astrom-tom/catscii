'''
This is the error file of catscii

Author: R. THOMAS
Place: ESO
Year: GPL v3.0
'''

class header_hash(Exception):
    def __init__(self, value):
        self.error = value

class header_length(Exception):
    def __init__(self, value):
        self.error = value



