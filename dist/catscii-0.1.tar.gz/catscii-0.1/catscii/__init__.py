from .catscii import *

###version
__version__ = 0.1

###author
__author__ = 'R. THOMAS'

###licence
__licence__ = 'GPL v3.0'

###year
__year__ = '2018'

